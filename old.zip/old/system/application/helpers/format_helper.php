<?php 

function shortAuthor($author) {
	return $author;
}

function debateDate($date) {
	return date('y',strtotime($date));
}

?>