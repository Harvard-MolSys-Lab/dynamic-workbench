$image_path = ".."

dir = File.dirname(__FILE__)

require File.join(dir, 'lib', 'theme_images.rb')
require File.join(dir, 'lib', 'utils.rb')

Compass::Frameworks.register 'ext4', dir