Ext.onReady(function() {
    Docs.App.init();
});
