Ext.data.JsonP.Ext_ComponentQuery_Query({
  "tagname": "class",
  "name": "Ext.ComponentQuery.Query",
  "doc": "\n",
  "extends": "Object",
  "mixins": [

  ],
  "alternateClassNames": [

  ],
  "xtype": null,
  "author": null,
  "docauthor": null,
  "singleton": false,
  "private": true,
  "cfg": [

  ],
  "method": [

  ],
  "property": [

  ],
  "event": [

  ],
  "filename": "/Users/nick/Projects/sencha/SDK/platform/src/ComponentQuery.js",
  "linenr": 238,
  "html_filename": "ComponentQuery.html",
  "href": "ComponentQuery.html#Ext-ComponentQuery-Query",
  "cssVar": [

  ],
  "cssMixin": [

  ],
  "component": false,
  "superclasses": [

  ],
  "subclasses": [

  ],
  "mixedInto": [

  ],
  "allMixins": [

  ]
});