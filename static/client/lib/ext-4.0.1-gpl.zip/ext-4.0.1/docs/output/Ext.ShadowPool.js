Ext.data.JsonP.Ext_ShadowPool({
  "tagname": "class",
  "name": "Ext.ShadowPool",
  "doc": "<p>Private utility class that manages the internal Shadow cache</p>\n",
  "extends": "Object",
  "mixins": [

  ],
  "alternateClassNames": [

  ],
  "xtype": null,
  "author": null,
  "docauthor": null,
  "singleton": false,
  "private": true,
  "cfg": [

  ],
  "method": [

  ],
  "property": [

  ],
  "event": [

  ],
  "filename": "/Users/nick/Projects/sencha/SDK/extjs/src/ShadowPool.js",
  "linenr": 1,
  "html_filename": "ShadowPool.html",
  "href": "ShadowPool.html#Ext-ShadowPool",
  "cssVar": [

  ],
  "cssMixin": [

  ],
  "component": false,
  "superclasses": [

  ],
  "subclasses": [

  ],
  "mixedInto": [

  ],
  "allMixins": [

  ]
});