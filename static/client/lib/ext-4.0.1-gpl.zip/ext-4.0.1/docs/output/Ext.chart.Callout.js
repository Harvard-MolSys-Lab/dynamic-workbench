Ext.data.JsonP.Ext_chart_Callout({
  "tagname": "class",
  "name": "Ext.chart.Callout",
  "doc": "\n",
  "extends": null,
  "mixins": [

  ],
  "alternateClassNames": [

  ],
  "xtype": null,
  "author": null,
  "docauthor": null,
  "singleton": false,
  "private": true,
  "cfg": [

  ],
  "method": [

  ],
  "property": [

  ],
  "event": [

  ],
  "filename": "/Users/nick/Projects/sencha/SDK/platform/src/chart/Callout.js",
  "linenr": 1,
  "html_filename": "Callout.html",
  "href": "Callout.html#Ext-chart-Callout",
  "cssVar": [

  ],
  "cssMixin": [

  ],
  "component": false,
  "superclasses": [

  ],
  "subclasses": [

  ],
  "mixedInto": [
    "Ext.chart.series.Series"
  ],
  "allMixins": [

  ]
});