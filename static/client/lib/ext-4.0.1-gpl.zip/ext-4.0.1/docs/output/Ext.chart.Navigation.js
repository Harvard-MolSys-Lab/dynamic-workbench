Ext.data.JsonP.Ext_chart_Navigation({
  "tagname": "class",
  "name": "Ext.chart.Navigation",
  "doc": "<p>Handles panning and zooming capabilities.</p>\n",
  "extends": null,
  "mixins": [

  ],
  "alternateClassNames": [

  ],
  "xtype": null,
  "author": null,
  "docauthor": null,
  "singleton": false,
  "private": true,
  "cfg": [

  ],
  "method": [

  ],
  "property": [

  ],
  "event": [

  ],
  "filename": "/Users/nick/Projects/sencha/SDK/platform/src/chart/Navigation.js",
  "linenr": 1,
  "html_filename": "Navigation.html",
  "href": "Navigation.html#Ext-chart-Navigation",
  "cssVar": [

  ],
  "cssMixin": [

  ],
  "component": false,
  "superclasses": [

  ],
  "subclasses": [

  ],
  "mixedInto": [
    "Ext.chart.Chart"
  ],
  "allMixins": [

  ]
});