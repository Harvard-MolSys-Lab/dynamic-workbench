Ext.data.JsonP.Ext_chart_Shape({
  "tagname": "class",
  "name": "Ext.chart.Shape",
  "doc": "\n",
  "extends": null,
  "mixins": [

  ],
  "alternateClassNames": [

  ],
  "xtype": null,
  "author": null,
  "docauthor": null,
  "singleton": false,
  "private": true,
  "cfg": [

  ],
  "method": [

  ],
  "property": [

  ],
  "event": [

  ],
  "filename": "/Users/nick/Projects/sencha/SDK/platform/src/chart/Shape.js",
  "linenr": 1,
  "html_filename": "Shape.html",
  "href": "Shape.html#Ext-chart-Shape",
  "cssVar": [

  ],
  "cssMixin": [

  ],
  "component": false,
  "superclasses": [

  ],
  "subclasses": [

  ],
  "mixedInto": [

  ],
  "allMixins": [

  ]
});