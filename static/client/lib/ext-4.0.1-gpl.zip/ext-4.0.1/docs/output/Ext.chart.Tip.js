Ext.data.JsonP.Ext_chart_Tip({
  "tagname": "class",
  "name": "Ext.chart.Tip",
  "doc": "\n",
  "extends": null,
  "mixins": [

  ],
  "alternateClassNames": [

  ],
  "xtype": null,
  "author": null,
  "docauthor": null,
  "singleton": false,
  "private": true,
  "cfg": [

  ],
  "method": [

  ],
  "property": [

  ],
  "event": [

  ],
  "filename": "/Users/nick/Projects/sencha/SDK/platform/src/chart/Tip.js",
  "linenr": 1,
  "html_filename": "Tip4.html",
  "href": "Tip4.html#Ext-chart-Tip",
  "cssVar": [

  ],
  "cssMixin": [

  ],
  "component": false,
  "superclasses": [

  ],
  "subclasses": [

  ],
  "mixedInto": [
    "Ext.chart.series.Series"
  ],
  "allMixins": [

  ]
});