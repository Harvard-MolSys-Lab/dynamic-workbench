Ext.data.JsonP.Ext_chart_axis_Abstract({
  "tagname": "class",
  "name": "Ext.chart.axis.Abstract",
  "doc": "\n",
  "extends": null,
  "mixins": [

  ],
  "alternateClassNames": [

  ],
  "xtype": null,
  "author": null,
  "docauthor": null,
  "singleton": false,
  "private": true,
  "cfg": [

  ],
  "method": [

  ],
  "property": [

  ],
  "event": [

  ],
  "filename": "/Users/nick/Projects/sencha/SDK/platform/src/chart/axis/Abstract.js",
  "linenr": 1,
  "html_filename": "Abstract.html",
  "href": "Abstract.html#Ext-chart-axis-Abstract",
  "cssVar": [

  ],
  "cssMixin": [

  ],
  "component": false,
  "superclasses": [

  ],
  "subclasses": [
    "Ext.chart.axis.Axis",
    "Ext.chart.axis.Gauge",
    "Ext.chart.axis.Radial"
  ],
  "mixedInto": [

  ],
  "allMixins": [

  ]
});