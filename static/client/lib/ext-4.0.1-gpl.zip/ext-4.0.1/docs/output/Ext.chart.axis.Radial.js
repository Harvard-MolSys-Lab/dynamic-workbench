Ext.data.JsonP.Ext_chart_axis_Radial({
  "tagname": "class",
  "name": "Ext.chart.axis.Radial",
  "doc": "\n",
  "extends": "Ext.chart.axis.Abstract",
  "mixins": [

  ],
  "alternateClassNames": [

  ],
  "xtype": null,
  "author": null,
  "docauthor": null,
  "singleton": false,
  "private": true,
  "cfg": [

  ],
  "method": [

  ],
  "property": [

  ],
  "event": [

  ],
  "filename": "/Users/nick/Projects/sencha/SDK/platform/src/chart/axis/Radial.js",
  "linenr": 1,
  "html_filename": "Radial.html",
  "href": "Radial.html#Ext-chart-axis-Radial",
  "cssVar": [

  ],
  "cssMixin": [

  ],
  "component": false,
  "superclasses": [
    "Ext.chart.axis.Abstract"
  ],
  "subclasses": [

  ],
  "mixedInto": [

  ],
  "allMixins": [

  ]
});