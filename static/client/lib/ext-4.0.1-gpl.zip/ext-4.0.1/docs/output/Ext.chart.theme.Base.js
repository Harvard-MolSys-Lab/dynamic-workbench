Ext.data.JsonP.Ext_chart_theme_Base({
  "tagname": "class",
  "name": "Ext.chart.theme.Base",
  "doc": "<p>Provides default colors for non-specified things. Should be sub-classed when creating new themes.</p>\n",
  "extends": null,
  "mixins": [

  ],
  "alternateClassNames": [

  ],
  "xtype": null,
  "author": null,
  "docauthor": null,
  "singleton": false,
  "private": true,
  "cfg": [

  ],
  "method": [

  ],
  "property": [

  ],
  "event": [

  ],
  "filename": "/Users/nick/Projects/sencha/SDK/platform/src/chart/theme/Base.js",
  "linenr": 1,
  "html_filename": "Base2.html",
  "href": "Base2.html#Ext-chart-theme-Base",
  "cssVar": [

  ],
  "cssMixin": [

  ],
  "component": false,
  "superclasses": [

  ],
  "subclasses": [

  ],
  "mixedInto": [

  ],
  "allMixins": [

  ]
});