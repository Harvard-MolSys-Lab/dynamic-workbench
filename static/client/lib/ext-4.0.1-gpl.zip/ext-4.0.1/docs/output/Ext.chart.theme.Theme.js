Ext.data.JsonP.Ext_chart_theme_Theme({
  "tagname": "class",
  "name": "Ext.chart.theme.Theme",
  "doc": "\n",
  "extends": null,
  "mixins": [

  ],
  "alternateClassNames": [

  ],
  "xtype": null,
  "author": null,
  "docauthor": null,
  "singleton": false,
  "private": true,
  "cfg": [

  ],
  "method": [

  ],
  "property": [

  ],
  "event": [

  ],
  "filename": "/Users/nick/Projects/sencha/SDK/platform/src/chart/theme/Theme.js",
  "linenr": 1,
  "html_filename": "Theme.html",
  "href": "Theme.html#Ext-chart-theme-Theme",
  "cssVar": [

  ],
  "cssMixin": [

  ],
  "component": false,
  "superclasses": [

  ],
  "subclasses": [

  ],
  "mixedInto": [
    "Ext.chart.Chart"
  ],
  "allMixins": [

  ]
});