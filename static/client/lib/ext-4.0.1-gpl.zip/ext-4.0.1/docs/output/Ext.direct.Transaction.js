Ext.data.JsonP.Ext_direct_Transaction({
  "tagname": "class",
  "name": "Ext.direct.Transaction",
  "doc": "<p>Supporting Class for Ext.Direct (not intended to be used directly).</p>\n\n",
  "extends": "Object",
  "mixins": [

  ],
  "alternateClassNames": [
    "Ext.Direct.Transaction"
  ],
  "xtype": null,
  "author": null,
  "docauthor": null,
  "singleton": false,
  "private": false,
  "cfg": [

  ],
  "method": [
    {
      "tagname": "method",
      "name": "Transaction",
      "member": "Ext.direct.Transaction",
      "doc": "\n",
      "params": [
        {
          "type": "Object",
          "name": "config",
          "doc": "\n",
          "optional": false
        }
      ],
      "return": {
        "type": "void",
        "doc": "\n"
      },
      "private": false,
      "static": false,
      "filename": "/Users/nick/Projects/sencha/SDK/platform/src/direct/Transaction.js",
      "linenr": 1,
      "html_filename": "Transaction.html",
      "href": "Transaction.html#Ext-direct-Transaction-method-constructor",
      "shortDoc": "\n"
    }
  ],
  "property": [

  ],
  "event": [

  ],
  "filename": "/Users/nick/Projects/sencha/SDK/platform/src/direct/Transaction.js",
  "linenr": 1,
  "html_filename": "Transaction.html",
  "href": "Transaction.html#Ext-direct-Transaction",
  "cssVar": [

  ],
  "cssMixin": [

  ],
  "component": false,
  "superclasses": [

  ],
  "subclasses": [

  ],
  "mixedInto": [

  ],
  "allMixins": [

  ]
});