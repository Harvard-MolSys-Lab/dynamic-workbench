Ext.data.JsonP.Ext_env_FeatureDetector({
  "tagname": "class",
  "name": "Ext.env.FeatureDetector",
  "doc": "\n",
  "extends": null,
  "mixins": [

  ],
  "alternateClassNames": [

  ],
  "xtype": null,
  "author": null,
  "docauthor": null,
  "singleton": false,
  "private": false,
  "cfg": [

  ],
  "method": [

  ],
  "property": [

  ],
  "event": [

  ],
  "filename": "/Users/nick/Projects/sencha/SDK/platform/core/src/env/FeatureDetector.js",
  "linenr": 1,
  "html_filename": "FeatureDetector.html",
  "href": "FeatureDetector.html#Ext-env-FeatureDetector",
  "cssVar": [

  ],
  "cssMixin": [

  ],
  "component": false,
  "superclasses": [

  ],
  "subclasses": [

  ],
  "mixedInto": [

  ],
  "allMixins": [

  ]
});