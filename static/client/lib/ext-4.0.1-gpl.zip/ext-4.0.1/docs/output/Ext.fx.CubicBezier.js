Ext.data.JsonP.Ext_fx_CubicBezier({
  "tagname": "class",
  "name": "Ext.fx.CubicBezier",
  "doc": "\n",
  "extends": null,
  "mixins": [

  ],
  "alternateClassNames": [

  ],
  "xtype": null,
  "author": null,
  "docauthor": null,
  "singleton": false,
  "private": true,
  "cfg": [

  ],
  "method": [

  ],
  "property": [

  ],
  "event": [

  ],
  "filename": "/Users/nick/Projects/sencha/SDK/platform/src/fx/CubicBezier.js",
  "linenr": 1,
  "html_filename": "CubicBezier.html",
  "href": "CubicBezier.html#Ext-fx-CubicBezier",
  "cssVar": [

  ],
  "cssMixin": [

  ],
  "component": false,
  "superclasses": [

  ],
  "subclasses": [

  ],
  "mixedInto": [

  ],
  "allMixins": [

  ]
});