Ext.data.JsonP.Ext_fx_PropertyHandler({
  "tagname": "class",
  "name": "Ext.fx.PropertyHandler",
  "doc": "\n",
  "extends": null,
  "mixins": [

  ],
  "alternateClassNames": [

  ],
  "xtype": null,
  "author": null,
  "docauthor": null,
  "singleton": false,
  "private": true,
  "cfg": [

  ],
  "method": [

  ],
  "property": [

  ],
  "event": [

  ],
  "filename": "/Users/nick/Projects/sencha/SDK/platform/src/fx/PropertyHandler.js",
  "linenr": 1,
  "html_filename": "PropertyHandler.html",
  "href": "PropertyHandler.html#Ext-fx-PropertyHandler",
  "cssVar": [

  ],
  "cssMixin": [

  ],
  "component": false,
  "superclasses": [

  ],
  "subclasses": [

  ],
  "mixedInto": [

  ],
  "allMixins": [

  ]
});