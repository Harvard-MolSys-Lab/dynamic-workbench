Ext.data.JsonP.Ext_fx_Queue({
  "tagname": "class",
  "name": "Ext.fx.Queue",
  "doc": "<p>Animation Queue mixin to handle chaining and queueing by target.</p>\n",
  "extends": null,
  "mixins": [

  ],
  "alternateClassNames": [

  ],
  "xtype": null,
  "author": null,
  "docauthor": null,
  "singleton": false,
  "private": true,
  "cfg": [

  ],
  "method": [

  ],
  "property": [

  ],
  "event": [

  ],
  "filename": "/Users/nick/Projects/sencha/SDK/platform/src/fx/Queue.js",
  "linenr": 1,
  "html_filename": "Queue.html",
  "href": "Queue.html#Ext-fx-Queue",
  "cssVar": [

  ],
  "cssMixin": [

  ],
  "component": false,
  "superclasses": [

  ],
  "subclasses": [

  ],
  "mixedInto": [
    "Ext.fx.Manager"
  ],
  "allMixins": [

  ]
});