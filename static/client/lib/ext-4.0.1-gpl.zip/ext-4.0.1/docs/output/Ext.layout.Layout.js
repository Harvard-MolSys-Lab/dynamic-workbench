Ext.data.JsonP.Ext_layout_Layout({
  "tagname": "class",
  "name": "Ext.layout.Layout",
  "doc": "<p>Base Layout class - extended by ComponentLayout and ContainerLayout</p>\n",
  "extends": "Object",
  "mixins": [

  ],
  "alternateClassNames": [

  ],
  "xtype": null,
  "author": null,
  "docauthor": null,
  "singleton": false,
  "private": true,
  "cfg": [

  ],
  "method": [

  ],
  "property": [

  ],
  "event": [

  ],
  "filename": "/Users/nick/Projects/sencha/SDK/platform/src/layout/Layout.js",
  "linenr": 1,
  "html_filename": "Layout.html",
  "href": "Layout.html#Ext-layout-Layout",
  "cssVar": [

  ],
  "cssMixin": [

  ],
  "component": false,
  "superclasses": [

  ],
  "subclasses": [
    "Ext.layout.component.Component",
    "Ext.layout.container.AbstractContainer"
  ],
  "mixedInto": [

  ],
  "allMixins": [

  ]
});