Ext.data.JsonP.Ext_view_TableChunker({
  "tagname": "class",
  "name": "Ext.view.TableChunker",
  "doc": "<p>Produces optimized XTemplates for chunks of tables to be\nused in grids, trees and other table based widgets.</p>\n",
  "extends": null,
  "mixins": [

  ],
  "alternateClassNames": [

  ],
  "xtype": null,
  "author": null,
  "docauthor": null,
  "singleton": true,
  "private": false,
  "cfg": [

  ],
  "method": [

  ],
  "property": [

  ],
  "event": [

  ],
  "filename": "/Users/nick/Projects/sencha/SDK/extjs/src/view/TableChunker.js",
  "linenr": 1,
  "html_filename": "TableChunker.html",
  "href": "TableChunker.html#Ext-view-TableChunker",
  "cssVar": [

  ],
  "cssMixin": [

  ],
  "component": false,
  "superclasses": [

  ],
  "subclasses": [

  ],
  "mixedInto": [

  ],
  "allMixins": [

  ]
});