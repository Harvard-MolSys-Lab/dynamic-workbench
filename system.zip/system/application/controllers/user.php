<?
class User extends Controller {
	function index()
	{
		$this->load->library('zend','Zend/Json');
		if($this->quickauth->logged_in()) {
			$user = $this->quickauth->user();
			$json = json_encode(array(
				'name' => $user->name,
				'id' => $user->id,
				'email' => $user->username
			));
			$this->output->set_output('App.User.setUser('.$json.');');
		}
	}
}	
/*
// Start the session for this page
session_start();
header("Cache-control: private");
*/


?>
